export const version = "3.1";
export const domain = "https://nqapp.nurulquran.com"
