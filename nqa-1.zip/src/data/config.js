export const version = "3.2";
export const domain = "https://nqapp.nurulquran.com"
